﻿#ifndef SARIBBONAPPLICATIONBUTTON_H
#define SARIBBONAPPLICATIONBUTTON_H
#include <QPushButton>
#include "SARibbonGlobal.h"
class /*SA_RIBBON_EXPORT*/ SARibbonApplicationButton : public QPushButton
{
    Q_OBJECT
public:
    SARibbonApplicationButton(QWidget* parent);
};

#endif // SARIBBONAPPLICATIONBUTTON_H
