﻿#include "SARibbonCheckBox.h"
#include <QStyleOption>
SARibbonCheckBox::SARibbonCheckBox(QWidget *parent)
    :QCheckBox(parent)
{
}

