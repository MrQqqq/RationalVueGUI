﻿#include "SARibbonApplicationButton.h"

SARibbonApplicationButton::SARibbonApplicationButton(QWidget *parent)
    :QPushButton(parent)
{
    setFlat(true);
}
