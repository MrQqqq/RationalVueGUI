﻿#ifndef SARIBBONCONTROLBUTTON_H
#define SARIBBONCONTROLBUTTON_H
#include <QToolButton>
#include "SARibbonGlobal.h"
class /*SA_RIBBON_EXPORT*/ SARibbonControlButton : public QToolButton
{
    Q_OBJECT
public:
    SARibbonControlButton(QWidget* parent = 0);
};

#endif // SARIBBONPANNELTOOLBUTTON_H
